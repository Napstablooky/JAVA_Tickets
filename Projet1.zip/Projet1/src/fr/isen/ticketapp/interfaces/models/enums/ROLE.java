package fr.isen.ticketapp.interfaces.models.enums;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("e6bb05fe-d308-4e93-b843-131c3e65cbbf")
public enum ROLE {
    Utilisateur,
    Intervenant;
}
