package fr.isen.ticketapp.interfaces.models;

import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.enums.ETATTICKET;
import fr.isen.ticketapp.interfaces.models.enums.IMPACT;

@objid ("ecb864d3-576d-4df5-beb0-fc539c36c3d9")
public class TicketModel {
    @objid ("e33ba036-5011-4192-8894-0d4889d1e635")
    public int id;

    @objid ("5056ccd3-3428-4729-b9a7-d39ede83c0fe")
    public IMPACT impact;

    @objid ("5310caad-f32e-4cb4-bf28-7109faafa143")
    public String titre;

    @objid ("3a7b4d2f-9f06-47b9-9e80-bc2656c51e9c")
    public String description;

    @objid ("bed5e698-57ec-4cac-aaac-a494658bbecb")
    public Date date_crea;

    @objid ("91591f0f-7f7d-40b5-a70f-1ae583b1334b")
    public ETATTICKET etat;

    @objid ("51e60787-4a3a-41d3-8cfe-992b7b5ed090")
    public Date date_maj;

    @objid ("ffd564f8-c915-4e02-b425-6f857fc11c3f")
    public UserModel createur;

    @objid ("e943a41f-3437-44bd-a158-8042d95dbd2f")
    public PosteInfoModel poste_info;

    @objid ("c89735e9-8f11-4660-9570-07dff43354d9")
    public String type_demande;

}
