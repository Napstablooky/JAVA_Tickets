package fr.isen.ticketapp.interfaces.models.enums;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0678ea34-1e5d-4bfc-bd3a-039bed2e8b9e")
public enum IMPACT {
    Bloquant,
    Mineur,
    Majeur;
}
