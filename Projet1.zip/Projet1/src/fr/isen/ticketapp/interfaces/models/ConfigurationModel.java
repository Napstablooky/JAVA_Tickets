package fr.isen.ticketapp.interfaces.models;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d04370e9-7bf9-45f9-9da7-257fcbf857c9")
public class ConfigurationModel {
    @objid ("1a1b29bc-4892-49aa-b987-f83c54360dbd")
    public String processeur;

    @objid ("45dfb312-902c-42a3-8bf6-31af7ab9fa3f")
    public String RAM;

    @objid ("1ec376bc-f3f5-4279-b757-4a4ae46dbf3d")
    public String stockage;

    @objid ("5b65cb60-48c7-4a23-abcd-053d76c19f14")
    public String gpu;

    @objid ("ccb372e4-64da-454f-b0ea-6d5bb5f6134c")
    public String os;

    @objid ("f1307085-7f3e-4ac8-ba2c-3788c2ff8f6c")
    public String ecran;

}
