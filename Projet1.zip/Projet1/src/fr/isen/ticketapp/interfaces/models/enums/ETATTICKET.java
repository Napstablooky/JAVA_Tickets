package fr.isen.ticketapp.interfaces.models.enums;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("20f191b2-847a-41f8-9c90-8703899ec604")
public enum ETATTICKET {
    Ouvert,
    En cours,
    Resolu,
    Ferme,
    Annule;
}
