package fr.isen.ticketapp.interfaces.models;

import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.enums.ETATPOSTE;

@objid ("c419a035-3300-4eb4-a960-d0e4decc863d")
public class PosteInfoModel {
    @objid ("106259da-edad-47c0-a8c3-6924754740f6")
    public int id;

    @objid ("422c9fdd-bca4-4322-8f27-471e57c7243e")
    public UserModel user;

    @objid ("2667e128-f264-42d1-8765-6f066b0e202f")
    public ETATPOSTE etat;

    @objid ("66556944-b37b-419f-a44f-8d7bb74f7c57")
    public ConfigurationModel configuration;

}
