package fr.isen.ticketapp.interfaces.models;

import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;
import fr.isen.ticketapp.interfaces.models.enums.ROLE;

@objid ("41689145-b339-4b8b-86c5-319c9d98b21e")
public class UserModel {
    @objid ("e6646f86-eb93-4ac9-8edf-89ce521e03fa")
    public int id;

    @objid ("afcf5d48-d166-48d3-a768-7d083f68bab1")
    public String nom;

    @objid ("b9bcd28a-8784-434b-903a-07aac1bcb77c")
    public String email;

    @objid ("0efbea7d-ce3e-4de1-8230-a1551bcbdb54")
    public String password;

    @objid ("a5fecf6d-1359-43e1-b41f-30e3258fc73d")
    public Date last_connexion;

    @objid ("82b0fbcf-63b1-41cd-a253-4461951dc87e")
    public boolean statut;

    @objid ("a7d6ac72-81a1-4548-8cf6-02c80737de6e")
    public ROLE role;

}
