package fr.isen.ticketapp.interfaces.models.enums;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5df4a637-31cf-441a-9396-46cfbd0c0193")
public enum ETATPOSTE {
    En Fonction,
    En maintenance,
    En commande;
}
